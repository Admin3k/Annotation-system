<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:73:"F:\phpstudy\WWW\thinkphp\public/../application/admin\view\index\show.html";i:1553782918;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<title>数据标注</title>
	<style type="text/css">
		.pagination li{
			display:inline;
			padding-right: 20px;
			list-style: none;
		}
		ul li{list-style: none;}
	</style>
</head>
<body>
	<div>
	<ul>
	<?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$user): $mod = ($i % 2 );++$i;?>
	    <li> <?php echo $user['did']; ?>数据：<?php echo $user['tagdata']; ?>标签：<?php echo $user['lable']; ?></li>
	<?php endforeach; endif; else: echo "" ;endif; ?>
	</ul>
	</div>
	<?php echo $list->render(); ?>
</body>
</html>