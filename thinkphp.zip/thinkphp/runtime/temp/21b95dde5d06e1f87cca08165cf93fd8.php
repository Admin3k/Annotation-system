<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:74:"F:\phpstudy\WWW\thinkphp\public/../application/index\view\index\index.html";i:1553782292;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>小米闪购 - 小米商城 </title>
   <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="/thinkphp/public/static/css/css/style.css">
    <link rel="stylesheet" href="/thinkphp/public/static/css/css/iconfont.css">
    
</head>
<body>
	
    <div class="topbar">
        <div class="container">
            <div class="dh1">
            </div>
            
            <div class="dh3 clearfix">
                <a href="<?php echo url('index/login'); ?>">登录</a><span>|</span>
                <a href="<?php echo url('index/zc'); ?>">注册</a><span>|</span>
            </div>
            
        </div>




    </div>
    <div class="header">
        <div class="container">
            <div class="header-log">
                <a href="#" class="lr">小米商城</a>
            </div>
            <div class="header-nav">
                <ul class="nav-list clearfix">
                    <li class="nav-dd">
                        <a href="">全部商品分类</a>
                    </li>
                    <li class="nav-item">
                        <a href="">小米手机</a>
                    </li>
                    <li class="nav-item">
                        <a href="">红米</a>
                    </li>
                    <li class="nav-item">
                        <a href="">电视</a>
                    </li>
                    <li class="nav-item">
                        <a href="">笔记本</a>
                    </li>
                    <li class="nav-item">
                        <a href="">家电</a>
                    </li>
                    <li class="nav-item">
                        <a href="">新品</a>
                    </li>
                    <li class="nav-item">
                        <a href="">路由器</a>
                    </li>
                    <li class="nav-item">
                        <a href="">智能硬件</a>
                    </li>
                    <li class="nav-item">
                        <a href="">服务</a>
                    </li>
                    <li class="nav-item">
                        <a href="">社区</a>
                    </li>
                </ul>

            </div>
            <div class="header-search">
				<!--
                <form action="" class="search-form">
                    <input type="search" name="keyword" class="search-txt">
                    <input type="submit" value="&#xe651;" class="search-anniu iconfont">
    
                </form>
-->



            </div>




        </div>


    </div>
    





</body>
</html>