<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:70:"F:\phpstudy\WWW\thinkphp\public/../application/index\view\bbs\bbs.html";i:1552567005;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>
<body>
	<p>用户列表</p>>
	<?php foreach($data as $key=>$v): ?>
		序号:<?php echo $v['Id']; ?>=>用户名:<?php echo $v['admin']; ?>=>密码:<?php echo $v['pwd']; ?>=>邮箱:<?php echo $v['email']; ?><br />
	<?php endforeach; ?>
</body>
</html>