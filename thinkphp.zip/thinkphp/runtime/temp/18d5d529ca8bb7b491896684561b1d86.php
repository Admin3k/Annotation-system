<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:74:"F:\phpstudy\WWW\thinkphp\public/../application/index\view\index\login.html";i:1553063137;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<title>用户登录</title>
</head>
<body>
	<form action="<?php echo url('index/loyz'); ?>" method="POST">
		用户名：<input type="text" name="name"><br />
		密码：<input type="password" name="pwd">
		<input type="submit" value="登录">
	</form>
</body>
</html>