<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:69:"F:\phpstudy\WWW\thinkphp\public/../application/index\view\bbs\bq.html";i:1552567016;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<p>标注数据</p>
		<?php foreach($data as $key=>$v): ?>
		ID:<?php echo $v['Id']; ?>=>标注内容:<?php echo $v['bd']; ?>=>标签:<?php echo $v['bq']; ?>=>是否标注:<?php echo $v['da']; ?><br />
	<?php endforeach; ?>
</body>
</html>