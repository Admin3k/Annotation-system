<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:73:"F:\phpstudy\WWW\thinkphp\public/../application/index\view\test\muban.html";i:1552465425;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>表格</title>
</head>
<body>
    <table border="2">
        <tr>
            <th><?php echo $name; ?></th>
            <th><?php echo $email; ?></th>
            <th><?php echo $data['a']; ?></th>
            <th><?php echo $data['b']; ?></th>
        </tr>
        <tr>
            <td>1</td>
            <td>1</td>
            <td>1</td>
            <td>1</td>
        </tr>
    </table>






    
</body>
</html>