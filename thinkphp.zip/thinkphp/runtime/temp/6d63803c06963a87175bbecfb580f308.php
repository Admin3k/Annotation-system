<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:73:"F:\phpstudy\WWW\thinkphp\public/../application/index\view\home\index.html";i:1553782490;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>小米闪购 - 小米商城 </title>
   <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="/thinkphp/public/static/css/css/style.css">
    <link rel="stylesheet" href="/thinkphp/public/static/css/css/iconfont.css">
    
</head>
<body>


    </div>
    <div class="header">
        <div class="container">
            <div class="header-log">
                <a href="#" class="lr"></a>
            </div>
            <div class="header-nav">
                <ul class="nav-list clearfix">
                    <li class="nav-dd">
                        <a href=""></a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo url('home/rw'); ?>">任务领取</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo url('home/bz'); ?>">数据标注</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo url('index/yj'); ?>">佣金查看</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo url('index/logout'); ?>">注销登录</a>
                    </li>
                    <li class="nav-item">
                        <a href=""></a>
                    </li>
                    <li class="nav-item">
                        <a href=""></a>
                    </li>
                    <li class="nav-item">
                        <a href=""></a>
                    </li>
                    <li class="nav-item">
                        <a href=""></a>
                    </li>
                    <li class="nav-item">
                        <a href=""></a>
                    </li>
                    <li class="nav-item">
                        <a href=""></a>
                    </li>
                </ul>

            </div>
            <div class="header-search">
				<!--
                <form action="" class="search-form">
                    <input type="search" name="keyword" class="search-txt">
                    <input type="submit" value="&#xe651;" class="search-anniu iconfont">
    
                </form>
-->



            </div>




        </div>


    </div>
    





</body>
</html>