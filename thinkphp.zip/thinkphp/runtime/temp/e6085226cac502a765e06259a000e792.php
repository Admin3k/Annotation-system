<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:69:"F:\phpstudy\WWW\thinkphp\public/../application/index\view\bbs\bz.html";i:1552993796;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<title>数据标注</title>
</head>
<body>
	<form action="<?php echo url('bbs/cl'); ?>" method="POST">
	<?php foreach($data as $key=>$v): ?>
		<?php echo $v['Id']; ?>
		<input type="hidden" name="id[<?php echo $v['Id']; ?>]">
		<!--<input type="text" name="id[<?php echo $v['Id']; ?>]"><br />-->
		.标注数据:<?php echo $v['bd']; ?><br />
		标签：<input type="text" name="bq[]"><br />
	<?php endforeach; ?>
		<input type="submit" name="tj" value="提交">
	</form>
</body>
</html>