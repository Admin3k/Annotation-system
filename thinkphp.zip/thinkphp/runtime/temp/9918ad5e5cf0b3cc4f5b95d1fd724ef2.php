<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:70:"F:\phpstudy\WWW\thinkphp\public/../application/index\view\home\bz.html";i:1553954447;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<title>数据标注</title>
	<style type="text/css">
		.pagination li{
			display:inline;
			padding-right: 20px;
			list-style: none;
		}
		ul li{list-style: none;}
	</style>
</head>
<body>
	<form action="<?php echo url('home/cl'); ?>" method="POST">
	<div>
	<ul>
		<a href="<?php echo url('home/index'); ?>">返回上页</a>
	<?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$user): $mod = ($i % 2 );++$i;?>
		<input type="hidden" name="id[]" value="<?php echo $user['did']; ?>">
	    <li> <?php echo $user['did']; ?>&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $user['tagdata']; ?></li>
	    <select name="tag[]">
		  <option value ="volvo">Volvo</option>
		  <option value ="saab">Saab</option>
		  <option value="opel">Opel</option>
		  <option value="audi">Audi</option>
		</select>
	<?php endforeach; endif; else: echo "" ;endif; ?>
	</ul>
	</div>
	<?php echo $list->render(); ?>
	<input type="submit" value="Submit" />
	</form>
</body>
</html>