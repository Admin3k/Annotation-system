<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:74:"F:\phpstudy\WWW\thinkphp\public/../application/admin\view\index\index.html";i:1553049214;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<title>管理员登录页面</title>
</head>
<body>
	<form action="<?php echo url('admin/pd'); ?>" method="POST">
		用户名：<input type="text" name="name"><br />
		密码：<input type="password" name="pwd"><br />
		<input type="submit" value="提交">
	</form>
</body>
</html>