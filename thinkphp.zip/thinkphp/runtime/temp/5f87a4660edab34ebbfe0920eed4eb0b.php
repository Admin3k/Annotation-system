<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:71:"F:\phpstudy\WWW\thinkphp\public/../application/index\view\index\zc.html";i:1553062357;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<title>用户注册</title>
</head>
<body>
	<form action="<?php echo url('index/yz'); ?>" method="POST">
		用户名：<input type="text" name="name"><br />
		密码：<input type="password" name="pwd"><br />
		邮箱:<input type="text" name="email"><br />
		年龄：<input type="text" name="age"><br />
		<input type="submit" value="注册">
	</form>
</body>
</html>