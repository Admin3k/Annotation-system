表对应关系	一对一  一对多 多对多
创建外键关联
一对一关系创建
CREATE TABLE person(id int PRIMARY key auto_increment,name varchar(50));
CREATE TABLE car(name varchar(20),color varchar(20),pid int,
	CONSTRAINT 	c_p_fk FOREIGN KEY (pid) REFERENCES person(id)	
);
多对多
新建一个中间表
A B C 
A对B-C
C对B-A